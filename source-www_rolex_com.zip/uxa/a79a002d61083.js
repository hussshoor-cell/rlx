//15.263.3-es2019 (a79a002d61083)
var CS_CONF={"collectionEnabled":true,"useSentry":false,"projectId":613,"status":1,"hostnames":["rolex.com","rolex.cn"],"crossDomainTracking":1,"crossDomainSingleIframeTracking":1,"consentRequired":0,"allowSubdomains":1,"visitorCookieTimeout":34164000000,"sampleRate":100,"replayRecordingRate":50,"validationRate":1,"lastTrackingDraw":1768300766,"trackerDomain":"c.contentsquare.net","recordingDomain":"r.contentsquare.net","useMalkaPipeline":1,"ed":"l.contentsquare.net/log/web","eMerchandisingEnabled":0,"mouseMoveHeatmapEnabled":1,"jsErrorsEnabled":1,"customErrorsEnabled":1,"jsCustomErrorsEnabled":0,"apiErrorsEnabled":1,"customHashIdEnabled":1,"recordingEncryptionEnabled":1,"recordingEncryptionPublicKey":"MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAzLL+InovBBU9UyNyekNAKah120BayP/5Sb+Iynbw7Uk9V4p9DUd+fCsAkkZf4xcymveSGPV6FPM6qdFag5IFHyXpGlc2bLAPZoyltk+/Iiji6gjwQBDzIUu8ERc+NeXKJvglb2TaDs3YXKK3PTvnq9VHya87rNxtkIepNBdroOthU7BVGiMQ5Pm0KzEwXCWmsTzdzgUfwVtvOf6Aw5u2Y+iho4avei4qSuK+fWaXP5ku537I5Wpt4lQT5H0Ed9GHNcr7SzebPsopRPpHCWz+6DUUT8D//4/Hgco1FQG0tbkQ8PN6FHuhvBlofFXTI0tSAREFr+mw9Bp/wP/ltYSG182wucR0J+Spcvq01GhvnCBatktAOLfNS39hSON40dJmyHgpv4OO8FDf332GhZhl8thPGqkBIF7RIZudDVwZVx3UoHN4khcapdyGRtEhfIqO5eOnjHIT8TLRtW4WC14rLCvNZWCZMJ0ewtq+2gUQSIYUfbUJAVDsnRMWeDhchHlEumXj2v9XVhURMG6cG4jFA+wuFPoh5A1VUveVMD2zlvpwNaRQJIPvwHfabhSxwNpmkFkgnfPaQDEmX3XPdjib1tL/ufAFdXLIiXhlvLqpfm1KkRjg8ynRE+1z+Oh7Urp0R4fF3y9KPPKbESdpV+SlndHW58+ypU0BEcbvbwmkJkcCAwEAAQ==","recordingEncryptionPublicKeyId":5664,"secureCookiesEnabled":0,"triggerSessionReplayEnabled":0,"triggerSessionReplayRegex":null,"dynamicIdRegex":null,"whitelistedAttributes":[],"replayRecordingUnmaskedUrlRegex":null,"replayRecordingUnmaskedUrlRegexRules":[],"replayRecordingMaskedUrlRegexRules":[],"replayRecordingMaskedUrlRegex":null,"anonymisationMethod":null,"tagDeploymentMode":"CONTENTSQUARE","experimental":null,"iframesTracking":0,"textVisibilityEnabled":1,"cookielessTrackingEnabled":0,"malkaUrlEnabled":0,"malkaEtrEnabled":1,"pathComputationRules":{"reliableSelectors":[],"uniqueAttributes":[],"uniqueCssSelectors":[]},"asyncSerializerEnabled":1,"pendingInactivityTimeout":5000,"accessibilityEnabled":0,"uxaDomain":"app.contentsquare.com","webviewsTrackingEnabled":0,"useStaticResourceManager":1,"performanceTimingOptions":{"withNavigation":true,"withResource":true},"replayConsentRequiredForSession":0,"eventsApiEnabled":0,"clickedElementTextEnabled":0,"collectHierarchy":0,"collectSubmit":0,"collectTargetText":0,"displayAdOptions":null,"taskSchedulerOptions":{"enabled":1},"malkaQuotaServiceDomain":"q-aeu1.contentsquare.net","malkaRecordingDomain":"k-aeu1.contentsquare.net","staticResourceManagerDomain":"srm.ba.contentsquare.net","voc":{"siteId":5233028,"enabled":1},"customErrors":{"consoleMessageLogLevels":[]},"apiErrors":{"collectStandardHeaders":0,"collectionRules":[{"bodyAttributePaths":[],"collectQueryParam":1,"collectRequestBody":1,"collectResponseBody":0,"customHeaders":[],"url":"contentstack.com","statusCode":429}]},"anonymizeDigits":null,"dynamicConfDomain":"t.contentsquare.net/settings","tagVerificationDomain":"tcvsapi.contentsquare.com","startMode":1,"trackingCodeVerified":true,"experiments":{"list":[]},"isLegacyHJ":false,"maskMedia":false,"tagVerificationEnabled":true,"urlBlacklist":null,"useBootstrapFile":true};
var CS_INTEGRATIONS_CONF = {"adobe-target":[]};
(function(){function e(){return window.csqDebuggerEnabled===!0||window.location.href.includes(`csqDebuggerEnabled=true`)}function t(t,n,r=`info`){if(!e())return;let i=r===`warn`?`rgb(255, 86, 2)`:`#2a9d8f`;console.log(`%cCSQ INTEGRATION: [${t}] : ${n}`,`color: ${i}; font-weight: bold`)}function n(e,t){let n=document.getElementById(`csKey`),r=document.getElementById(`csValue`);return n!==null&&(n.textContent=e),r!==null&&(r.textContent=String(t)),`Dynamic variable with ${e} and value ${t} sent`}function r(){return window._uxa=window._uxa||[],window._uxa}function i(e){return e instanceof Error?e.message:String(e)}function a(t,n){try{t()}catch(t){r().push([`logSnippetError`,n,t]),e()&&(console.log(`%cCSQ INTEGRATION ERROR: [${n}] : ${i(t)}`,`color:rgb(228, 25, 45); font-weight: bold`),console.log(t))}}function o(e,t){var n,r;(n=window).CS_CONF!=null||(n.CS_CONF={integrations:[]}),(r=window.CS_CONF).integrations!=null||(r.integrations=[]);let i={name:e,version:t};window.CS_CONF.integrations.push(i)}function s(e,t){var n,r;let i=(n=window.CS_INTEGRATIONS_CONF)==null?void 0:n[e];return i==null||(r=i.find(e=>e.key===t))==null?void 0:r.value}function c(e,t){r().push([`trackDynamicVariable`,{key:e,value:t}])}function l(e,r){return(i,a)=>{let o=`${r}${i}`;c(o,a),t(e,n(o,a))}}function u(e,t,n=window){let r=e.split(`.`);function i(e,n){let a=r[e];a!==void 0&&(e===r.length-1?d(a,t,n):d(a,()=>{let t=n[a];t!==void 0&&i(e+1,t)},n))}i(0,n)}function d(e,t,n){let r=n;if(r[e]){t();return}let i,a=!1;Object.defineProperty(r,e,{configurable:!0,enumerable:!0,get(){return i},set(e){i=e,a||(a=!0,t())}})}var f=`adobe-target`,p=l(f,`AB_AT_`),m=[];a(()=>{var e;o(`Adobe Target`,`3.8.2`);let t=s(f,`customObjectName`),n=(e=t==null?void 0:t.trim())==null?`ttMETA`:e;document.addEventListener(`at-request-succeeded`,e=>{a(()=>{var t;g((t=e.detail)==null?void 0:t.responseTokens)},f)}),u(n,()=>_(n))},f);function h(e){return e.CampaignName&&e.RecipeName?{campaignName:e.CampaignName,variationName:e.RecipeName}:e.campaign&&e.experience?{campaignName:e.campaign,variationName:e.experience}:e[`activity.name`]&&e[`experience.name`]?{campaignName:e[`activity.name`],variationName:e[`experience.name`]}:null}function g(e){if(Array.isArray(e))for(let t of e){let e=h(t);if(!e)continue;let{campaignName:n,variationName:r}=e,i=`${n}~~~~${r}`;m.includes(i)||(m.push(i),p(n,r))}}function _(e){setTimeout(()=>{g(window[e])},500)}})();
function injectTag(stable, candidate, share) {
  if (typeof CS_CONF === "undefined") {
    return;
  }
  const d2 = document;
  const logUrl = `https://${CS_CONF.ed}`;
  const pid = CS_CONF.projectId;
  function log2(message2, level = "critical") {
    const page = location.origin + location.pathname;
    const msg = `${logUrl}?a=uxa&l=${level}&m=${encodeURIComponent(message2)}&pid=${pid}&p=${encodeURIComponent(page)}`;
    fetch(msg, { mode: "cors", credentials: "omit", keepalive: true }).catch(
      () => {
        const image = new Image();
        image.crossOrigin = "anonymous";
        image.src = msg;
      }
    );
  }
  const currentScript = document.currentScript;
  const hjDomains = ["static-integration.hotjar.com", "static.hotjar.com"];
  const isHotjar = hjDomains.some((x2) => currentScript?.src.includes(x2));
  const origin = isHotjar ? new URL(currentScript.src).origin : "https://t.contentsquare.net";
  const rollout = candidate && share ? { arm: Math.random() < share ? "candidate" : "stable" } : null;
  CS_CONF.rollout = rollout;
  const path2 = rollout?.arm === "candidate" && candidate ? candidate : stable;
  const expectedSrc = new URL(`${origin}/${path2}`).href;
  const element = d2.createElement("script");
  let stopped = false;
  let errorTimer;
  const observer = new MutationObserver((records) => checkAttributes(records));
  function cleanup() {
    stopped = true;
    clearTimeout(errorTimer);
    observer.disconnect();
    d2.removeEventListener("securitypolicyviolation", onCsp);
    element.onload = null;
    element.onerror = null;
  }
  function report(cause) {
    log2(`Bootstrap error: ${cause}`);
  }
  function checkAttributes(records = observer.takeRecords()) {
    if (stopped) return true;
    for (const attribute of ["src", "type"]) {
      const expected = attribute === "src" ? expectedSrc : null;
      const observed = element.getAttribute(attribute);
      if (attribute === "src" && element.src !== expectedSrc || observed !== expected || records.some(
        (record) => record.attributeName === attribute && record.oldValue !== expected
      )) {
        cleanup();
        report(`${attribute} changed observed=${JSON.stringify(observed)}`);
        return true;
      }
    }
    return false;
  }
  function onCsp(event) {
    if (stopped || !event.isTrusted || event.disposition !== "enforce" || !["script-src", "script-src-elem"].includes(event.effectiveDirective) || event.blockedURI !== expectedSrc && !(event.target === element && event.blockedURI === origin)) {
      return;
    }
    if (checkAttributes()) return;
    cleanup();
    report(
      `csp blocked directive=${event.effectiveDirective} blockedURI=${event.blockedURI}`
    );
  }
  d2.addEventListener("securitypolicyviolation", onCsp);
  element.onload = () => {
    if (!checkAttributes()) cleanup();
  };
  element.onerror = () => {
    if (checkAttributes() || errorTimer !== void 0) return;
    errorTimer = setTimeout(() => {
      if (checkAttributes()) return;
      cleanup();
      report("others");
    }, 0);
  };
  try {
    element.src = expectedSrc;
    element.async = true;
    element.fetchPriority = "high";
    element.crossOrigin = "anonymous";
    if (!checkAttributes()) {
      observer.observe(element, {
        attributes: true,
        attributeFilter: ["src", "type"],
        attributeOldValue: true
      });
    }
    (d2.head || d2.documentElement).appendChild(element);
    checkAttributes();
  } catch (error2) {
    cleanup();
    throw error2;
  }
}
injectTag("releases/15.263.3/es2019/3f3a00c-34ac688d.js");

// signature-6ceed87db199b26272f8938ac42700ebde5d828b0a05971ffd71dec72ae46524