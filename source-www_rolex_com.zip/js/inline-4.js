
      Promise.all([
        new Promise(resolve => {
            const test = () => {
              if ( !window.__consentready || !window.__rlx ) {
                setTimeout(test, 100)
              } else {
                resolve()
              }
            }
            test()
          }).then(() => window.__consentready),
          UA
      ]).then(([_,sdk]) => {
        const onconsent = () => {
          let language = window.__rlx.lang

          switch (language) {
            case "en-us":
              language = "en"
              break
            case "pt-br":
              language = "pt"
              break
            case "zh-hans":
            case "zh-hant":
              language = "zh"
              break
            default:
              break
          }

          sdk.locale.set({country :window.__rlx.countryCode, language }).then(() => {
            return sdk.create()
          }).then(function (result) {
            console.log("• UA Channel ID: %s", result.channelId, sdk, sdk.channel.optedIn())
            window.airshipID = result.channelId;
          })
        }

        window.didomiOnReady = window.didomiOnReady || []
        window.didomiOnReady.push((Didomi) => {
          const status = Didomi.getCurrentUserStatus()
          const allowed = status.vendors['urbanairs-PYddi2br']?.enabled || false
          if ( allowed ) {
            onconsent()
          }
          else {
            window.airshipID = null
          }
        })
      })
      