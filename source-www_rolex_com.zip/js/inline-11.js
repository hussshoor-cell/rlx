_satellite["_runScript7"](function(event, target, Promise) {
_satellite.track("ddl-consent-ready");
});