_satellite["_runScript2"](function(event, target, Promise) {
_satellite.setVar("CC-Airshipconsent",!0);
});