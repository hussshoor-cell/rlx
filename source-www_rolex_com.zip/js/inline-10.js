_satellite["_runScript6"](function(event, target, Promise) {
_satellite.setVar("CC-Analyticsconsent",!0);
});