_satellite["_runScript4"](function(event, target, Promise) {
_satellite.setVar("CC-COconsent",!0),_satellite.getVar("CC - CoveoLib");
});